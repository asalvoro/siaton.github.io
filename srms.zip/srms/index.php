<?php
	session_start();
ini_set('display_errors', 1);
?>
<?php include 'header.php';?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
	</head>
<body>
	<nav class="navbar navbar-default">
	
	</nav>
	<div class="col-md-3"></div>
	<div class="col-md-6 well">
        <center><h3><b>Siaton Public Market <br> Log-in Portal</b></h3></center>
		<hr style="border-top:1px dotted #ccc;"/>
		<div class="col-md-2"><!-- /.navbar-header -->
<!-- /.navbar-top-links --></div>
		<div class="col-md-8">
              
            

            
			<?php if(isset($_SESSION['message'])): ?>
				<div class="alert alert-<?php echo $_SESSION['message']['alert'] ?> msg"><?php echo $_SESSION['message']['text'] ?></div>
			<script>
				(function() {
					// removing the message 3 seconds after the page load
					setTimeout(function(){
						document.querySelector('.msg').remove();
					},3000)
				})();
			</script>
			<?php 
				endif;
				// clearing the message
				unset($_SESSION['message']);
			?>
            
			<form action="login.php" method="POST">	
				<h4 class="text-success">Login here...</h4>
				<hr style="border-top:1px groovy #000;">
				<div class="form-group">
					<input type="text" class="form-control" placeholder="Username" name="username" />
				</div>
				<div class="form-group">
					<input type="password" class="form-control" placeholder="Password" name="password" />
				</div>
				<br />
				<div class="form-group">
					<button class="btn btn-primary form-control" name="login">Login</button>
				</div>
				
			</form> 
                   
		</div>
	</div>
</body>
</html>