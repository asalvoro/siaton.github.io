<?php
	$db_username = 'root';
	$db_password = 'usbw';
	$conn = new PDO( 'mysql:host=localhost;dbname=vccdms', $db_username, $db_password );
	if(!$conn){
		die("Fatal Error: Connection Failed!");
	}
?>

